<?php
 $db = mysqli_connect('localhost', 'root', '','saana') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'saana' ) or die(mysqli_error($db));
?>